﻿# GroupOfFour — SWR302 GMS Submission Pack (v1.0)

Structure per assignment A.3.

## Notes
- ERD: `03_Images/ERD_Conceptual.png`
- AD: `AD_ActivateMembership.png` (AD-03). Additional ADs may live inside `GMS.vpp`.
- SMD PNG: tables in repo `docs/step7/thien_smd.md`; export `SMD_Membership.png` / `SMD_PTBooking.png` from Visual Paradigm when available and re-zip.
- RTM: `04_Traceability_Matrix.xlsx` (Traceability + NFR sheets)
- TeamWork: equal 25% self-assessment × 4 members; MSSV filled.

Date: 11/11/2026
